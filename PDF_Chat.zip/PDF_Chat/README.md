PDF QA App (RAG over PDFs)

Overview
This is a Streamlit web application that lets users upload a PDF and ask questions about its content. The app uses a Retrieval-Augmented Generation (RAG) pipeline: it extracts text from the PDF, splits it into chunks, embeds those chunks, retrieves the most relevant passages for a query, and then asks a Large Language Model (LLM) to answer grounded in that context.

Key Features
- PDF upload and processing (tested on large PDFs)
- RAG pipeline with FAISS similarity search
- Multi‑provider LLM selection (OpenAI, Google Gemini, Anthropic, Cohere)
- Provider‑specific API key input in the UI
- Adjustable top‑k retrieval and optional context viewer with similarity scores
- Dynamic suggested questions based on the uploaded document
- Summary presets: Executive, Technical, and Student (downloadable)
- Source expander and answer download
- Clean layout: controls in the right sidebar; centered Q&A under the title

Architecture
1) Extract text: PyPDF2 reads pages → combined text
2) Chunk text: RecursiveCharacterTextSplitter
3) Embed: Google Generative AI embeddings (models/embedding-001)
4) Index: FAISS vector store (in‑memory)
5) Retrieve: top‑k similarity search (default k=4)
6) Generate: selected LLM produces the answer from retrieved docs

Requirements
- Python 3.10+

Install
```bash
pip install -U streamlit langchain langchain-google-genai langchain-openai langchain-anthropic langchain-cohere faiss-cpu PyPDF2 nest_asyncio
```

Run
```bash
streamlit run pdf.py
```

Usage
1) Open the app in your browser (Streamlit prints the local URL)
2) In the right sidebar:
   - Choose an LLM provider and model
   - Paste the corresponding API key
   - Upload your PDF
   - Optionally tweak top‑k and show retrieved context
3) In the center area under the title:
   - Enter your question and view the answer
   - Download the answer if needed
4) Optional: Generate summaries (Executive/Technical/Student) and download

Providers
- OpenAI: set OPENAI_API_KEY
- Google Gemini: set GOOGLE_API_KEY
- Anthropic: set ANTHROPIC_API_KEY
- Cohere: set COHERE_API_KEY

Notes
- If a provider SDK isn’t installed, the app falls back to Gemini automatically.
- For very large PDFs, the first indexing may take some time.

Project Structure
```
.
├── pdf.py            # Streamlit app
├── README.md         # This file
└── ...               # Assets / notebooks
```

Security
- API keys are read from the sidebar input and set in environment variables only for the current process.

License
MIT

